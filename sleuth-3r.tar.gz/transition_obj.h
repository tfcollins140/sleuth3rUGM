
void
trans_Init();

void trans_MemoryLog(FILE* fp);
void
trans_LogTransition();
double* trans_GetClassSlope();
double* trans_GetFTransition();
