void pgrid_MemoryLog(FILE* fp);
int pgrid_GetPGridCount();
void pgrid_Init();
GRID_P pgrid_GetZPtr();
GRID_P pgrid_GetDeltatronPtr();
GRID_P pgrid_GetDeltaPtr();
GRID_P pgrid_GetLand1Ptr();
GRID_P pgrid_GetLand2Ptr();
GRID_P pgrid_GetCumulatePtr();

