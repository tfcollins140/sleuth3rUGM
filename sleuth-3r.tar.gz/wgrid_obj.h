
int wgrid_GetWGridCount();
void wgrid_SetWGridCount( int );
