#ifndef DRIVER_H
#define DRIVER_H

#ifdef DRIVER_MODULE
  /* stuff visable only to the driver module */
char driver_h_sccs_id[] = "@(#)driver.h	1.228	12/4/00";

  
#endif
/* #defines visable to any module including this header file*/


void
  drv_driver ();
#endif
