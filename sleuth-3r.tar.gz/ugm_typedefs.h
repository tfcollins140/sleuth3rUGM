#ifndef UGM_TYPEDEFS_H
#define UGM_TYPEDEFS_H

#ifdef MAIN_MODULE
  #ifndef UGM_TYPDEFS_H_SCCS_ID
    #define UGM_TYPDEFS_H_SCCS_ID
    char ugm_typedefs_h_sccs_id[] = "@(#)ugm_typedefs.h	1.189	12/4/00";
  #endif
#endif

typedef double stats_data_t;
typedef double road_percent_t;

#endif
